
"use strict";

let Student = require('./Student.js');

module.exports = {
  Student: Student,
};
