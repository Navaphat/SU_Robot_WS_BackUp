
"use strict";

let Multiply = require('./Multiply.js')

module.exports = {
  Multiply: Multiply,
};
